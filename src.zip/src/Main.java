import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        // 指定当前文件夹下的1.txt文件路径
        String filePath = "src/1.txt";
        DirectedGraph graph = new DirectedGraph();

        // 读取文件并生成有向图
        try {
            graph.generateGraph(filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 打印有向图的邻接表表示
        System.out.println("Original Text:");
        System.out.println(graph.getProcessedText());
        System.out.println("\nAdjacency List:");
        System.out.println(graph);
        //////////////////////////////////
        // 示例：查询桥接词
//        String word1 = "";
//        String word2 = "san";
//        List<String> bridgeWords = graph.queryBridgeWords(word1, word2);
//        if (bridgeWords == null) {
//            if (!graph.adjacencyList.containsKey(word1.toLowerCase()) || !graph.adjacencyList.containsKey(word2.toLowerCase())) {
//                System.out.println("No word1 or word2 in the graph!");
//            } else {
//                System.out.println("No bridge words from word1 to word2!");
//            }
//        } else {
//            System.out.println("The bridge words from " + word1 + " to " + word2 + " are: " + bridgeWords);
//        }
        /////////////////////////////////////////////////
        //

        //据bridge word生成新文本
//        String userInput = "Seek to explore new and exciting synergies";
//        String newText = graph.generateNewTextWithBridgeWords(userInput);
//        System.out.println("\nNew Text with Bridge Words:");
//        System.out.println(newText);
//        //////////////////////////////////////////////
//       最短距离
        String word1 = "and";
        String word2 = "worlds";
        String shortestPath = graph.calcShortestPath(word1, word2);
        System.out.println(shortestPath);
        ////////////////////////////////////
        //：随机游走
        //
//        List<String> traversalPath = graph.randomWalk();
//
//        // 将遍历的节点写入文件
//        String outputFilePath = "path.txt"; // 可以指定输出文件路径
//        graph.writeTraversalToFile(traversalPath, outputFilePath);
//
//        // 打印遍历的节点
//        System.out.println("Traversal Path:");
//        for (String node : traversalPath) {
//            System.out.println(node);
//        }

    }


    static class DirectedGraph {
        private Map<String, Map<String, Integer>> adjacencyList = new HashMap<>();
        private StringBuilder originalText = new StringBuilder(); // 存储原始文本
        private volatile boolean stopWalk = false;
        public List<String> queryBridgeWords(String word1, String word2) {
            word1 = word1.toLowerCase();
            word2 = word2.toLowerCase();

            // 检查word1和word2是否在图中
            if (!adjacencyList.containsKey(word1) || !adjacencyList.containsKey(word2)) {

                return null;
            }

            Set<String> bridgeWordsSet = new HashSet<>(); // 使用HashSet来避免重复的桥接词
            for (String adjacentWord : adjacencyList.get(word1).keySet()) {
                if (adjacencyList.containsKey(adjacentWord) && adjacencyList.get(adjacentWord).containsKey(word2)) {
                    bridgeWordsSet.add(adjacentWord);
                }
            }

            // 转换为List并返回
            List<String> bridgeWords = new ArrayList<>(bridgeWordsSet);
            if (bridgeWords.isEmpty()) {
                //System.out.println("No bridge words from word1 to word2!");
            }
            return bridgeWords;
        }
        public void generateGraph(String filePath) throws IOException {
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    // 添加原始文本
                    originalText.append(line).append("\n");
                    // 处理每一行文本
                    processLine(line);
                }
            }
        }

        private void processLine(String line) {
            String[] words = line.replaceAll("[^a-zA-Z\\s]", " ").toLowerCase().split("\\s+");
            for (int i = 0; i < words.length - 1; i++) {
                String current = words[i];
                String next = words[i + 1];
                addEdge(current, next, 1);
            }
        }

        private void addEdge(String from, String to, int weight) {
            // 获取当前节点的邻接表，如果不存在则创建一个新的HashMap
            Map<String, Integer> edges = adjacencyList.computeIfAbsent(from, k -> new HashMap<>());
            // 使用三元运算符来获取边的当前权重，如果不存在则为0
            int currentWeight = edges.getOrDefault(to, 0);
            // 更新边的权重
            edges.put(to, currentWeight + weight);
        }

        public String getProcessedText() {
            // 使用正则表达式移除非字母字符，并将所有文本转换为小写
            String processedText = originalText.toString().replaceAll("[^a-zA-Z\\s]", "").toLowerCase();
            // 移除非必要的空白字符
            processedText = processedText.trim().replaceAll("\\s+", " ");
            return processedText;
        }
        public String generateNewTextWithBridgeWords(String input) {
            String[] words = input.split("\\s+");
            List<String> newWords = new ArrayList<>();
            Random rand = new Random();

            for (int i = 0; i < words.length - 1; i++) {
                newWords.add(words[i]);
                List<String> bridgeWords = queryBridgeWords(words[i], words[i + 1]);
                if (bridgeWords != null && !bridgeWords.isEmpty()) {
                    // 随机选择一个bridge word
                    String selectedBridgeWord = bridgeWords.get(rand.nextInt(bridgeWords.size()));
                    newWords.add(selectedBridgeWord);
                }
            }
            newWords.add(words[words.length - 1]); // 添加最后一个词

            return String.join(" ", newWords);
        }

        // Dijkstra算法找到从startWord到endWord的最短路径
        public String calcShortestPath(String word1, String word2) {
            if (!adjacencyList.containsKey(word1) || !adjacencyList.containsKey(word2)) {
                return "One or both of the words are not in the graph.";
            }

            Map<String, Double> distances = new HashMap<>();
            Map<String, String> previous = new HashMap<>();
            Set<String> visited = new HashSet<>(); // 初始化访问集合
            PriorityQueue<Map.Entry<String, Double>> pq = new PriorityQueue<>(Comparator.comparing(Map.Entry::getValue));

            // 初始化所有节点的距离为无穷大，并将起点的距离设置为0
            for (String node : adjacencyList.keySet()) {
                distances.put(node, Double.MAX_VALUE);
            }
            distances.put(word1, 0.0);

            // 将起点加入优先队列
            pq.offer(new AbstractMap.SimpleEntry<>(word1, distances.get(word1)));

            while (!pq.isEmpty()) {
                Map.Entry<String, Double> currentEntry = pq.poll();
                String currentNode = currentEntry.getKey();
                double currentDistance = currentEntry.getValue();

              //  System.out.println("Original Text:");
                if (currentNode.equals(word2)) {
                    // 如果当前节点是目标节点，开始重建路径
                    return reconstructPath(previous, word2);
                }

                if (!visited.contains(currentNode)) { // 检查当前节点是否已访问
                    visited.add(currentNode); // 标记当前节点为已访问

                    Map<String, Integer> neighbors = adjacencyList.get(currentNode);//获取节点邻居
                    if (neighbors != null) {
                        for (Map.Entry<String, Integer> edge : neighbors.entrySet()) {//遍历邻居节点
                            String neighbor = edge.getKey();
                            int weight = edge.getValue();
                            double distanceThroughU = currentDistance + weight;
//                           找到了更短的路径
                            if (distances.getOrDefault(neighbor, Double.MAX_VALUE) > distanceThroughU) {
                                distances.put(neighbor, distanceThroughU);
                                previous.put(neighbor, currentNode);//用于重构图像
                                pq.offer(new AbstractMap.SimpleEntry<>(neighbor, distanceThroughU));//加入邻居
                            }
                        }
                    }
                }
            }

            // 如果没有找到路径
            return "No path exists between " + word1 + " and " + word2;
        }

        private String reconstructPath(Map<String, String> previous, String word2) {
            List<String> path = new ArrayList<>();
            String current = word2;
            while (current != null) {
                path.add(0, current); // 将当前节点添加到路径的开始
                current = previous.get(current); // 移动到前一个节点
            }
            return String.join(" → ", path);
        }
        // 执行随机游走的方法
        public List<String> randomWalk() {
            Map<String, Map<String, Integer>> adjListCopy = new HashMap<>(adjacencyList);
            List<String> traversalPath = new ArrayList<>();
            StringBuilder traversalText = new StringBuilder();
            String currentNode = chooseRandomNode(adjListCopy); // 随机选择起点
            traversalPath.add(currentNode);
            traversalText.append(currentNode).append(" ");

            boolean stop = false;
            while (!stop && adjListCopy.containsKey(currentNode)) {
                Map<String, Integer> edges = adjListCopy.get(currentNode);
                if (edges.isEmpty()) {
                    // 当前节点没有出边，停止游走
                    break;
                }
                String nextNode = chooseRandomNextNode(edges, traversalPath); // 随机选择下一个节点
                if (nextNode != null) {
                    traversalPath.add(nextNode);
                    traversalText.append(nextNode).append(" ");
                    currentNode = nextNode;
                } else {
                    // 遇到了重复的边，停止游走
                    stop = true;
                }
            }
            return traversalPath;
        }




        // 从图中随机选择一个节点作为起点
        private String chooseRandomNode(Map<String, Map<String, Integer>> adjListCopy) {
            List<String> nodes = new ArrayList<>(adjListCopy.keySet());
            Random random = new Random();
            return nodes.get(random.nextInt(nodes.size()));
        }

        // 确保不重复
        private String chooseRandomNextNode(Map<String, Integer> edges, List<String> traversalPath) {
            List<String> availableNodes = new ArrayList<>(edges.keySet());
            Collections.shuffle(availableNodes); // 打乱列表顺序
            for (String node : availableNodes) {
                if (!traversalPath.contains(node)) {
                    return node;
                }
            }
            return null; // 没有可用的节点或遇到重复边
        }

        // 将遍历的节点写入文件
        public void writeTraversalToFile(List<String> traversalPath, String filePath) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
                for (String node : traversalPath) {
                    writer.write(node);

                    writer.newLine();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        //
      //  @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, Map<String, Integer>> entry : adjacencyList.entrySet()) {
                sb.append(entry.getKey()).append(": ");
                for (Map.Entry<String, Integer> edge : entry.getValue().entrySet()) {
                    sb.append(edge.getKey()).append("(").append(edge.getValue()).append(") ");
                }
                sb.append("\n");
            }
            return sb.toString();
        }
    }

}